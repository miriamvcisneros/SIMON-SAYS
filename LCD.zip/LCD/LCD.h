#ifndef LCD_H
#define LCD_H

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>


class LCD16X2
{
 public:
    void init();
    void escribeLinea(char frase[],int linea);
    void clear();
    void apagar(void);
    void encender(void);
};
#endif
