﻿#include <Arduino.h>
#include <LCD.h>  
#define SCL 3
#define SDA 2

LiquidCrystal_I2C lcd(0x27, 16, 2); // Direccion I2C 16x2
 
void LCD16X2::init(){  
  Wire.begin();		//sda scl
  lcd.init();		//inica el LCD
  lcd.backlight();
 }
 
void LCD16X2::encender(void){
	lcd.backlight();	
}
void LCD16X2::apagar(void){
	lcd.noBacklight();
}

void LCD16X2::escribeLinea(char frase[],int linea){
  lcd.setCursor(0,linea);  //selecciona la pantalla del lcd a escribir (columna 0 de la fila 1)
  lcd.print(frase);    // pinta la frase pasada por parametro
}
void LCD16X2::clear(){
  lcd.clear();
}